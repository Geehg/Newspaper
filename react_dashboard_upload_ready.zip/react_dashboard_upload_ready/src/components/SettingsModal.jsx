import React from 'react';

export default function SettingsModal({ settings, setSettings }) {
  const togglePanel = (key) => {
    setSettings({
      ...settings,
      visible: {
        ...settings.visible,
        [key]: !settings.visible[key]
      }
    });
  };

  return (
    <div className="modal">
      <h3>사용자 설정</h3>
      <label>테마:
        <select value={settings.theme} onChange={e => setSettings({ ...settings, theme: e.target.value })}>
          <option value="auto">자동</option>
          <option value="light">라이트</option>
          <option value="dark">다크</option>
        </select>
      </label>
      <h4>패널 표시 설정</h4>
      {Object.entries(settings.visible).map(([key, val]) => (
        <label key={key}>
          <input type="checkbox" checked={val} onChange={() => togglePanel(key)} />
          {key.toUpperCase()}
        </label>
      ))}
    </div>
  );
}
