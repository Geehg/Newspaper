import React, { useRef, useEffect } from 'react';
import Sortable from 'sortablejs';
import Panel from './Panel';

export default function PanelGrid({ panels, setPanels, settings }) {
  const gridRef = useRef();

  useEffect(() => {
    const sortable = Sortable.create(gridRef.current, {
      animation: 150,
      onEnd: (evt) => {
        const newOrder = [...panels];
        const [moved] = newOrder.splice(evt.oldIndex, 1);
        newOrder.splice(evt.newIndex, 0, moved);
        setPanels(newOrder);
      }
    });
    return () => sortable.destroy();
  }, [panels]);

  return (
    <div className="grid" ref={gridRef}>
      {panels.filter(p => settings.visible[p.id]).map(p => (
        <Panel key={p.id} title={p.title} />
      ))}
    </div>
  );
}
