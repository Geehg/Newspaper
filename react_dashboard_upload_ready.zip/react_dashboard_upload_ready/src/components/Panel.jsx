import React from 'react';
export default function Panel({ title }) {
  return (
    <div className="panel">
      <h2>{title}</h2>
      <p>[{title} 패널 콘텐츠]</p>
    </div>
  );
}
