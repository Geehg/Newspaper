import React, { useState } from 'react';
import PanelGrid from './components/PanelGrid';
import SettingsModal from './components/SettingsModal';
import { useLocalStorage } from './hooks/useLocalStorage';

const defaultPanels = [
  { id: 'weather', title: 'WEATHER' },
  { id: 'dust', title: '🌫️ 미세먼지' },
  { id: 'calendar', title: 'CALENDAR' },
  { id: 'cctv', title: 'CCTV LIVE' },
  { id: 'notion', title: 'NOTION' },
  { id: 'rss', title: 'NEWS FEED' }
];

export default function App() {
  const [settings, setSettings] = useLocalStorage('settings', {
    theme: 'auto',
    city: 'Seoul',
    visible: {
      weather: true,
      dust: true,
      calendar: true,
      cctv: true,
      notion: true,
      rss: true
    }
  });

  const [panels, setPanels] = useLocalStorage('panels', defaultPanels);
  return (
    <div className={`app theme-${settings.theme}`}>
      <SettingsModal settings={settings} setSettings={setSettings} />
      <PanelGrid panels={panels} setPanels={setPanels} settings={settings} />
    </div>
  );
}
